import React from 'react';

// React Component using ES2015 class
/*
class OSComponent extends React.Component {
	render() {
		// this.props.os = "Linux";   // Properties are immutable
		return (
			<>
				<h1>Operating System: {this.props.os}</h1>
				<h3>Developed by {this.props.children}</h3>
			</>
		);
	}
}
*/

// React Component as a Functional Component
// [ <= React 16.7 - Stateless component ]  [ From 16.8 , State possible in Functional Component through React Hooks]
const OSComponent = (props) => {
	return (
		<div>
			<h1>Operating System: {props.os}</h1>
			<h3>Developed by {props.children}</h3>
		</div>
	)
}

export default class App extends React.Component {
	render() {
		return (
			<>
				<OSComponent os="Windows">Microsoft</OSComponent>
				<OSComponent os="Solaris">Sun Microsystems</OSComponent>
				<OSComponent os="iOS">Apple</OSComponent>
			</>
		);
	}
}

