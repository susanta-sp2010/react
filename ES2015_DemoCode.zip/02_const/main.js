// 1. ES5 way - Just declare the constant variable as ALL CAPS just as convention
var MIN_VALUE =  10;
MIN_VALUE = 20;
console.log("Declared through var => Minimum value = %d", MIN_VALUE);
//==============================================================================
// 2. ES2015 way - Through const
const MAX_VALUE = 1000;
// MAX_VALUE = 2000; //***
console.log("Declared through const => Maximum value = %d", MAX_VALUE);
//==============================================================================
// 3. ES2015 - const is a constant reference and not a constant variable
const DAYS = {};
DAYS.first = "SUNDAY"; // Properties of the object DAYS can be assigned without any problems.
DAYS.second = "MONDAY";
console.log("Days: ", DAYS);
// DAYS = "All days"; // But the reference cannot be re-assigned. //***
//==============================================================================
// 4. ES2015 - Like let, const is block scoped.
if (true) {
  const PI = 3.14;
}
console.log("PI=", PI); //*** Uncommenting this causes error which is normal
//==============================================================================
