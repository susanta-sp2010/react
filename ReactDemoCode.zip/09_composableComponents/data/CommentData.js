export default {
  comments:
  [
    {
      "id": 1,
      "author": "Ram",
      "text": "React is simple"
    },
    {
      "id": 2,
      "author": "Raj",
      "text": "React is fast"
    },
    {
      "id": 3,
      "author": "Vinay",
      "text": "React can be used to develop SPA"
    }
  ]
};
