import greet from './greetings.js';
import add from './math.js';
import { subtract as minus, multiply, divide, square } from './math.js';
import * as mathLib from './math.js';

// 1. Importing the only default exported function present in the module
console.log("1)  %s", greet('Vinay'));

// 2. Importing the default export function with other functions present as named exports
console.log("2)  10 + 20 = %d", add(10, 20));

// 3. Importing the named export functions (using an alias as well as directly)
console.log("3a) 9 - 3 = %d, 9 * 3 = %d, 9 / 3 = %d", minus(9, 3), multiply(9, 3), divide(9, 3));
console.log("3b) 5 * 5 = %d", square(5));

// 4. Importing all the exported functions (default as well as named) into an object named 'mathLib'
// default exported function will be invoked using default()
console.log("4a) 8 + 4 = %d", mathLib.default(8, 4));
// named exported functions will be invoked using their corresponding names
console.log("4b) 8 - 4 = %d, 8 * 4 = %d, 8 / 4 = %d", mathLib.subtract(8, 4), mathLib.multiply(8, 4), mathLib.divide(8, 4));
console.log("4c) 8 * 8 = %d", mathLib.square(8));
