import React from 'react';

// State concept  (Also, Controlled Components used here)
export default class App extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			empname: 'Ram',
			bManager: false
		};
	}

	handleTextChange(e) {
		this.setState({ empname: e.target.value })
	}

	//	Wrong way
	/*
	handleCheckbox() {
		this.setState({bManager: !this.state.bManager})
	}
	*/
	// Correct way for setting state based on previous state value = Through Arrow function
	handleCheckbox() {
		this.setState((prevState) => ({
			bManager: !prevState.bManager
		}));
	}

	render() {
		let role = this.state.bManager ? " Manager" : " Employee";
		return (
			<>
				<h2>State Demo</h2>
				<div>
					<label>
						Employee Name:
						<input type="text" value={this.state.empname} onChange={(e) => this.handleTextChange(e)} />
					</label>
					<label>
						<input type="checkbox" checked={this.state.bManager} onChange={() => this.handleCheckbox()} />
						Manager
					</label>
				</div>
				<p>{this.state.empname} is {role}</p>
			</>
		);
	}
}
