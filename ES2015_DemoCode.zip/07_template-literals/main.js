// 1. ES5 way - String concatenation
var name = "Vinay";
var message = "Welcome! " + name;
console.log("1) String concatenation => "); console.log(message);
//==============================================================================
// 2. ES 2015 way - Using Backtick (`)
var name1 = "Vinay";
var message1 = `Welcome! ${name}`;
console.log("\n2) Using Backtick => "); console.log(message1);
//==============================================================================
// 3. ES 2015 - Using Backtick (`) for multi-line strings, also $ allows for substitution of variables
var language = "JavaScript";
var multilineMessage  = `${language} was
    introduced in the 90s.
        The version used currently
          is ES5. A new version has been introduced
  which is ES6 or ES2015.`
console.log("\n3) Using Backtick for multi-line strings and also substitution => "); console.log(multilineMessage);
//==============================================================================
// 4. Apart from variables, you can also embed function calls, calculations in substitution.
function getUserName() {
  return "Sachin";
}

var numSixes = 3;
var numFours = 10;

var message2 = `The score of ${getUserName()} is ${numSixes*6 + numFours*4}`;
console.log("\n4) Using function calls, calculations in substitution => "); console.log(message2);
//==============================================================================
