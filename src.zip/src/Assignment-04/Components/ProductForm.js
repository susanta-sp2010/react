import React from 'react';

// Presentation Component - Pure UI (View)
export default class ProductForm extends React.Component {
    constructor(props) {
      super(props);
      this.refAuthor = React.createRef();
      this.refCommenttext = React.createRef();
    }

   /*  onSubmit (event) {
      event.preventDefault();
      let comment = {};
      comment.author = this.refAuthor.current.value;
      comment.text = this.refCommenttext.current.value;
      this.props.onSave(comment);
    } */

    render() {
        return (
            <form style={{margin:10}}>
                <h1>Add Product</h1>
                Product Name:&nbsp;
                <input type="text"
                    ref={this.refAuthor} /><br/><br/>
                Quantity: &nbsp;
                <input type="text"
                    ref={this.refCommenttext} /><br/><br/>
                Price: &nbsp;
                <input type="number" /><br/><br/>
                <input type="submit" value="Save" onClick={(e) => this.onSubmit(e)}/>
            </form>
        );
    }
}