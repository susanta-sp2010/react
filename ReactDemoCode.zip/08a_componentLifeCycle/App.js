import React from 'react';

export default class App extends React.Component {
    constructor(props) {
	    super(props);
        this.state = {
          name: "Raj"
        };
        console.log("constructor called")
    }

    UNSAFE_componentWillMount() {  // This is DEPRECATED and should not be used anymore.
        console.log("component will mount - DEPRECATED, should not be used")
    }

    componentDidMount() {
        console.log("component did mount")
    }

    UNSAFE_componentWillUpdate() {  // This is DEPRECATED and should not be used anymore.
        console.log("component will update - DEPRECATED, should not be used")
    }

    componentDidUpdate() {
        console.log("component did update")
    }

    handleTextInput(event) {
      this.setState({name: event.target.value});
    }

    render() {
        console.log("Inside render method ...");
        return (
            <div>
                <h1>Component Lifecycle - Update - demo</h1>
                <input type="text" defaultValue={this.state.name} onInput={(e) => this.handleTextInput(e)}/><br/><br/>
            </div>
        );
    }

    componentWillUnmount() {
        console.log("component will unmount")
    }

}
