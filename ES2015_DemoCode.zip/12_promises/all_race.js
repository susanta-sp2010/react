const maxTime = 2000;

let myMap1 = new Map();
myMap1.set(1, "Ram");
myMap1.set(2, "Raj");
myMap1.set(3, "Vinay");

// Promise.all
function getEmployeeName(id) {
  return new Promise((resolve, reject) => {
    let waitTime = Math.floor(Math.random()*(maxTime+1));
    console.log("waitTime=" + waitTime + " id= " + id);
    setTimeout(() => {
      if (id <= 3)
        resolve(myMap1.get(id));
      else
          reject("Invalid employee id");
    }, waitTime);
  });
}

let empids = [1, 2, 3];
let promises = [];
for (let i=0; i<empids.length; i++) {
  promises.push(getEmployeeName(empids[i]));
}

Promise.all(promises)
    .then(names => console.log(names))
    .catch(error => console.log(error));

// => UNCOMMENT the below code and COMMENT the Promise.all code above
// => to analyze the Promise.race behavior
/*
Promise.race(promises)
  .then(name => console.log(name))
  .catch(error => console.log(error));
*/
console.log("Getting the name of the list of employee IDs");
