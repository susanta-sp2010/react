import React from 'react'
import EmployeeForm from './components/EmployeeForm'

const App = () => <EmployeeForm/>

export default App