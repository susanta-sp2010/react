// 1. SINGLE ARGUMENT
// ES5 - Normal function
var square1 = function (x) {
  return x * x;
}
console.log(square1(5));

// ES2015 - Arrow function
let square2 = x => x * x;
console.log(square2(6));
//==============================================================================
// 2. MULTIPLE ARGUMENTS
// ES5 - Normal function
var addNumber1 = function (num1, num2) {
  return num1 + num2;
}
console.log(addNumber1(1, 2));

// ES2015 - Arrow function
let addNumber2 = (num1, num2) => num1 + num2;
console.log(addNumber2(3, 4));
//==============================================================================
// 3. Arrow function - TRADITIONAL FUNCTION BODY - braces { } and explicit return value
let addNumber3 = (num1, num2) => {
  return num1 + num2;
}
console.log(addNumber2(5, 6));
//==============================================================================
// 4. NO ARGUMENTS
var getCountry1 = function() {
    return "India";
};
console.log(getCountry1());

let getCountry2 = () => "India";
console.log(getCountry2());
//==============================================================================
// 5. FUNCTION THAT DOES NOTHING
// ES5 - Normal function
var functionEmpty1 = function() {};

// ES2015 - Arrow function - Include curly braces {}
let functionEmpty2 = () => {};
//==============================================================================
// 6. RETURNING AN OBJECT LITERAL
// ES5 - Normal function
var getUserInfo1 = function(id) {
  return {
        id: id,
        name: "Ram"
    };
};

// ES2015 - Arrow function - Wrap object literal in parantheses ( )
let getUserInfo2 = id => ({ id: id, name: "Ram" })
//==============================================================================
// 7. this in normal function - ES5
var Timer = {
	message: "Timer ended (ES5)",
	start: function() {
		setTimeout(function() {
			console.log(this.message);
		}.bind(this), 1000);
	}
}
Timer.start();
//==============================================================================
// 8. Arrow function does not have any this pointer - ES2015
let Timer1 = {
	message: "Timer ended (ES2015)",
	start: function() {
		setTimeout(() => console.log(this.message), 1000);
	}
}
Timer1.start();
//==============================================================================

