import React from 'react';
import  {withRouter} from 'react-router-dom';
import ProductForm from './ProductForm';

// Container Component
class AddProductPage extends React.Component {
    
    /* saveComment(comment) {
        CommentApi.saveComment(comment);
        this.props.history.push('/');
    }
 */
    render() {
        return (
            //<CommentForm onSave={(data) => this.saveComment(data)} />            
            <ProductForm/>
        );
    }
}

// HOC - Higher Order Component
export default withRouter(AddProductPage);