import React, { Component } from 'react'
import withItem from './withItem';

class CustomerList extends Component {
    render() {
        const { itemInputted, handleItemInput, items, addItem } = this.props;  // DESTRUCTURING - ES2015 concept
        let itemList = items.map((item, index) => (
            <li key={index}>{item}</li>
        ))
        return (
            <>
                <h2>{this.props.heading}</h2>
                <label>
                    Enter customer name:
                    <input type="text" value={itemInputted} onChange={(e) => handleItemInput(e)} />
                </label>
                <button onClick={() => addItem(itemInputted)}>Add Customer (HOC)</button>
                <ul>
                    {itemList}
                </ul>
            </>
        )
    }
}

// Argument false is passed to store name as it is
export default withItem(CustomerList, false)