import React from 'react';
import { BrowserRouter as Router, Route, Switch, NavLink } from 'react-router-dom';
import AllProductsPage from './Components/AllProductsPage';
import AddProductPage from './Components/AddProduct';
import AboutPage from './AboutPage';
import NotFoundPage from './NotFoundPage';

class Links extends React.Component {
    render() {
      return (
        <nav>
          <NavLink exact activeClassName="current" to="/">About</NavLink>
          <NavLink activeClassName="current" to="/products">Products</NavLink>          
        </nav>
      );
    }
  }

export default class App extends React.Component {
    render() {
        return (
            <Router>
                <div>
                    <Links />
                    <Switch>
                        <Route path="/products">
                            <AllProductsPage/>
                        </Route>
                        <Route path="/addProduct">
                            <AddProductPage></AddProductPage>
                        </Route>
                        <Route path="/">
                            <AboutPage />
                        </Route>
                        <Route path="*">
                            <NotFoundPage />
                        </Route>
                    </Switch>
                </div>
            </Router>
        );
    }
}