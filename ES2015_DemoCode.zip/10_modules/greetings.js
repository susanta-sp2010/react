export default function(name) {
  return `Welcome! ${name} to ES2015 modules`;
}
