// => export as the default function in this file
// => Only 1 function can be exported as default, others will be named
export default function (x, y) {
  return x + y;
}

// => Named function
// => exported separately below
function subtract (x, y) {
  return x - y;
}

// => Another way to name the function by storing the anonymous function in a constant variable, multiply
// => exported separately below
const multiply = function (x, y) {
  return x * y;
}

// => Same like multiply above but using arrow function syntax
// => exporting inline (another way of exporting)
export const divide = (x, y) => x / y;

// => Named function
// => exported separately below but with a different alias "square"
function sq (x) {
  return x * x;
}

export { subtract, multiply, sq as square };
