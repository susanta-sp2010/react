/* import axios from 'axios';

export default class ProductApi {
	static getAllProducts(cb) {
		axios.get('https://my-json-server.typicode.com/Susanta-Singh/ReactAssignments/products')
			.then(response => cb(response.data))
			.catch(error => { throw error });
	}
} */

import ProductData from './ProductData';

export default class ProductApi {
	static getAllProducts() {
	    return ProductData.products;
	}
}