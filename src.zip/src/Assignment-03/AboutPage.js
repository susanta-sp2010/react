import React from 'react';

export default () => <h1>About: Ths application provides information about the products</h1>