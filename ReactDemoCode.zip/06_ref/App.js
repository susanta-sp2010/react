import React from 'react';

// ref concept (Uncontrolled components)
export default class App extends React.Component {
	constructor(props) {
		super(props);
		this.refName = React.createRef();
		this.refLocation = React.createRef();
	}
	handleSubmit() {
		let name = this.refName.current.value;
		let location = this.refLocation.current.value;
		alert(`Name = ${name}, Location = ${location}`);
		this.refName.current.focus();
	}
	render() {
		return (
			<>
				<h2>Ref Demo</h2>
				<label>Enter your name:
					<input type="text" ref={this.refName} /><br /><br />
				</label>
				<label>Enter your location:
					<input type="text" ref={this.refLocation} /><br /><br />
				</label>
				<button onClick={() => this.handleSubmit()}>Submit</button>
			</>);
	}
}
