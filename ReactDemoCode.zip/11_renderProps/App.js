import React, { Component } from 'react'
import Item from './components/Item'
import EmployeeList from './components/EmployeeList'
import CustomerList from './components/CustomerList'

class App extends Component {
    render() {
        return (
            <>
                <Item isUpper={true}>
                    {(itemInputted, handleItemInput, items, addItem) => (
                        <EmployeeList 
                            itemInputted={itemInputted}
                            handleItemInput={handleItemInput}
                            items={items}
                            addItem={addItem}
                            heading="Employee List (Using Render Props)" />
                    )}
                </Item>
                <Item>
                    {(itemInputted, handleItemInput, items, addItem) => (
                        <CustomerList
                            itemInputted={itemInputted}
                            handleItemInput={handleItemInput}
                            items={items}
                            addItem={addItem}
                            heading="Customer List (Using Render Props)" />
                    )}
                </Item>
            </>
        )
    }
}

export default App