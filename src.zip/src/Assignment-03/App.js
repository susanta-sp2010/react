import React from 'react';
import { BrowserRouter as Router, Route, Switch, NavLink } from 'react-router-dom';
import AllProductsPage from './Components/AllProductsPage';
import AboutPage from './AboutPage';
import NotFoundPage from './NotFoundPage';

class Links extends React.Component {
    render() {
      return (
        <nav>
          <NavLink activeClassName="current" to="/">About</NavLink>
          <NavLink exact activeClassName="current" to="/products">Products</NavLink>          
        </nav>
      );
    }
  }

export default class App extends React.Component {
    render() {
        return (
            <Router>
                <div>
                    <Links />
                    <Switch>
                        <Route exact path="/">
                            <AllProductsPage/>
                        </Route>
                        <Route path="/about">
                            <AboutPage />
                        </Route>
                        <Route path="*">
                            <NotFoundPage />
                        </Route>
                    </Switch>
                </div>
            </Router>
        );
    }
}