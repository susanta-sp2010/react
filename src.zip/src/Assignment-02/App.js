import React from 'react';
import AllProductsPage from './Components/AllProductsPage';

export default class App extends React.Component {
    render() {
        return (
            <AllProductsPage/>
        );
    }
}