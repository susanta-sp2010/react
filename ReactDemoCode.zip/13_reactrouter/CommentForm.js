import React from 'react';

// Presentation Component - Pure UI (View)
export default class CommentForm extends React.Component {
    constructor(props) {
      super(props);
      this.refAuthor = React.createRef();
      this.refCommenttext = React.createRef();
    }

    onSubmit (event) {
      event.preventDefault();
      let comment = {};
      comment.author = this.refAuthor.current.value;
      comment.text = this.refCommenttext.current.value;
      this.props.onSave(comment);
    }

    render() {
        return (
            <form>
                <h1>Add Comment</h1>
                Author:&nbsp;
                <input type="text"
                    ref={this.refAuthor} /><br/><br/>
                Comment Text: &nbsp;
                <input type="text"
                    ref={this.refCommenttext} /><br/><br/>
                <input type="submit" value="Save" onClick={(e) => this.onSubmit(e)}/>
            </form>
        );
    }
}
