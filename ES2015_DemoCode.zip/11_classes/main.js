class Person {
  constructor(name, age) {
    this.name = name;
    this.age = age;
  }

// instance method
  speak() {
    return `${this.name} speaking...`;
  }
  
// static method
  static welcome() {
    return 'Welcome!';
  }
}

// Composition - has a relationship
// Inheritance - is a relationship
class Athelete extends Person {
  constructor(name, age, sportsCategory) {
    super(name, age);
    this.sportsCategory = sportsCategory;
  }

  run() {
    return `${this.name} running in ${this.sportsCategory}`;
  }

}

const person1 = new Person("Vinay", 27);
console.log(person1.speak());

const person2 = new Person("Sachin", 29);
console.log(person2.speak());


const athelete1 = new Athelete("Rahul", 25, "100m");
console.log(athelete1.run());
console.log(athelete1.speak());

console.log(Person.welcome());
console.log(Athelete.welcome());
