let empid = 2;

myMap1 = new Map();
myMap1.set(1, "Ram");
myMap1.set(2, "Raj");
myMap1.set(3, "Vinay");

myMap2 = new Map();
myMap2.set("Ram", "Chennai");
myMap2.set("Raj", "Pune");
myMap2.set("Vinay", "Bangalore");

myMap3 = new Map();
myMap3.set("Chennai", "Tamil Nadu");
myMap3.set("Pune", "Maharashtra");
myMap3.set("Bangalore", "Karnataka");


// Asynchronous way of calling functions sequentially using promise
// API implement
function getEmployeeName(id) {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      if (id <= 3)
        resolve(myMap1.get(id));
      else {
          reject("Invalid employee id");
      }
    }, 1000);
  });
}

function getEmployeeCity(name) {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      resolve(myMap2.get(name));
    }, 1000);
  });
}

function getEmployeeState(city) {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      resolve(myMap3.get(city));
    }, 1000);
  });
}

// User of API
getEmployeeName(empid)
  .then(name => getEmployeeCity(name))
  .then(city => getEmployeeState(city))
  .then(state => console.log(state))
  .catch(error => console.log(error));

console.log("Getting the state of the empid = " + empid);
