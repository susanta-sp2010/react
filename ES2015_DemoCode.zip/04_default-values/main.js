// 1. ES5 behavior - parameters
function welcomeMessage(message, name) {
  name = (typeof name !== "undefined") ? name : "Ram";
  console.log("%s! %s", message, name);
}
welcomeMessage();  // Displays Displays undefined! Ram
welcomeMessage("Hello", "Vinay"); // Displays Hello! Vinay

// 2. ES2015 way - default values for parameters
function welcomeMessageNew(message, name="Ram") {
  console.log("%s! %s", message, name);
}
welcomeMessageNew();  // Displays undefined! Ram
welcomeMessageNew("Hello"); // Displays Hello! Ram
welcomeMessageNew("Hello", "Sachin"); // Displays Hello! Sachin

// 3. ES2015 - Calling a function to get a default value for a parameter
function getDefaultUser() {
  return "Rahul";
}

function welcomeMessage2(message, name=getDefaultUser()) {
  console.log("%s! %s", message, name);
}
welcomeMessage2("Greetings"); // Displays Greetings! Rahul

// 4. ES5 behavior - function parameters
function display(welcomeFn) {
  welcomeFn();
}

//display(); // Says welcomeFn is not a function as undefined gets passed
display(function() {
  console.log("Welcome!");
});

// 5. ES2015 way - default value for function parameters
function displayNew(welcomeFn = () => console.log("Welcome by default!")) {
  welcomeFn();
}

displayNew(); // Displays Welcome by default! even if no parameter is passed
displayNew(function() {
  console.log("Hello overriding!");
});        // Hello! function overrides default function
