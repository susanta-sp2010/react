import React from 'react';
import { BrowserRouter as Router, Route, Redirect, Switch, NavLink } from 'react-router-dom';
import AllCommentsPage from './AllCommentsPage';
import AddCommentPage from './AddCommentPage';
import CommentDetailPage from './CommentDetailPage';
import AboutPage from './AboutPage';
import NotFoundPage from './NotFoundPage';

class Links extends React.Component {
  render() {
    return (
      <nav>
        <NavLink exact activeClassName="current" to="/">Comments</NavLink>
        <NavLink activeClassName="current" to="/about">About</NavLink>
      </nav>
    );
  }
}
export default class App extends React.Component {
  render() {
      return (
        <Router>
          <div>
            <Links />
            <Switch>
              <Route exact path="/">
                <AllCommentsPage />
              </Route>
              <Route path="/addComment">
                <AddCommentPage />
              </Route>
              <Route path="/comment/:id" component={CommentDetailPage} />
              <Route path="/about">
                <AboutPage />
              </Route>
              <Route path="/about-wipro">
                <Redirect to="/about" />
              </Route>
              <Route path="*">
                <NotFoundPage />
              </Route>
            </Switch>
          </div>
        </Router>
      );
  }
}
