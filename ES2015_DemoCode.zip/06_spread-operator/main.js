// 1. Normal Array vs Spreading the Array
let arrayNum1 = [1, 2];
console.log("Normal Array =>"); console.log(arrayNum1);
console.log("Spreading the Array =>"); console.log(...arrayNum1);
//==============================================================================
// 2. Combining Arrays - Normal combine vs Spread and combine
let arrayNum2 = [1, 2];
let arrayNum3 = [3, 4];
arrayNum2.push(arrayNum3);
console.log("\nNormal combine =>");  console.log(arrayNum2);

let arrayNum4 = [1, 2];
let arrayNum5 = [3, 4];
arrayNum4.push(...arrayNum5);
console.log("Spread and combine =>"); console.log(arrayNum4);
//==============================================================================
// 3. Using spread operators to pass an array to a function expecting an argument list
function sum (num1, num2, num3) {
  let result = num1 + num2 + num3;
  return result;
}
let arrayNum6 = [1, 2, 3];
console.log("\nIn ES5, using apply =>");console.log(sum.apply(null, arrayNum6)); // No need to do hereafter this way
console.log("Spreading array and passing to function =>"); console.log(sum(...arrayNum6));
//==============================================================================
