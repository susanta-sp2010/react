export default {
    products:
    [
      {
        "id": 1,
        "name": "Moto G5",
        "quantity": 2,
        "price": "Rs. 13000"
      },
      {
        "id": 2,
        "name": "Raclod Geyser",
        "quantity": 3,
        "price": "Rs. 6000"
      },
      {
        "id": 3,
        "name": "Dell Inspirion",
        "quantity": 4,
        "price": "Rs. 50000"
      }
    ]
  };  