import React from 'react';
import AllCommentsPage from './components/AllCommentsPage';

export default class App extends React.Component {
    render() {
        return (
            <AllCommentsPage/>
        );
    }
}
