import React from 'react';
import  {withRouter} from 'react-router-dom';

import CommentForm from './CommentForm';
import CommentApi from './data/CommentApi';

// Container Component
class AddCommentPage extends React.Component {
    
    saveComment(comment) {
        CommentApi.saveComment(comment);
        this.props.history.push('/');
    }

    render() {
        return (
            <CommentForm onSave={(data) => this.saveComment(data)} />
        );
    }
}

// HOC - Higher Order Component
export default withRouter(AddCommentPage);
